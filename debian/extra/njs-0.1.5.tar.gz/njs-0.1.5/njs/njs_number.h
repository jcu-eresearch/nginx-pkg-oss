
/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) NGINX, Inc.
 */

#ifndef _NJS_NUMBER_H_INCLUDED_
#define _NJS_NUMBER_H_INCLUDED_


#include <math.h>


double njs_value_to_number(njs_value_t *value);
double njs_number_parse(const u_char **start, const u_char *end);
int64_t njs_number_radix_parse(u_char *p, u_char *end, uint8_t radix,
    nxt_bool_t exact);
njs_ret_t njs_number_to_string(njs_vm_t *vm, njs_value_t *string,
    const njs_value_t *number);
njs_ret_t njs_number_constructor(njs_vm_t *vm, njs_value_t *args,
    nxt_uint_t nargs, njs_index_t unused);
njs_ret_t njs_number_global_is_nan(njs_vm_t *vm, njs_value_t *args,
    nxt_uint_t nargs, njs_index_t unused);
njs_ret_t njs_number_is_finite(njs_vm_t *vm, njs_value_t *args,
    nxt_uint_t nargs, njs_index_t unused);
njs_ret_t njs_number_parse_int(njs_vm_t *vm, njs_value_t *args,
    nxt_uint_t nargs, njs_index_t unused);
njs_ret_t njs_number_parse_float(njs_vm_t *vm, njs_value_t *args,
    nxt_uint_t nargs, njs_index_t unused);


extern const njs_object_init_t  njs_number_constructor_init;
extern const njs_object_init_t  njs_number_prototype_init;


#endif /* _NJS_NUMBER_H_INCLUDED_ */
